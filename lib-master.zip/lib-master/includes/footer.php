   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; Veritas Library Managment System|<a href='#' target="_blank"  > Designed by : Ntami</a> 
                </div>

            </div>
        </div>
    </section>